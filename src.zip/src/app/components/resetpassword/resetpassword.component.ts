import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { passwordMatchValidator } from '../validators/validtors';
// import { passwordMatchValidator } from 'src/app/components/validators/validtors';



@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent {
  resetForm!:FormGroup;
  constructor(private fb:FormBuilder,private auth:AuthService,private router: Router,private route: ActivatedRoute){}
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const email = params['Email'];
      const token = params['token'];

      this.resetForm = this.fb.group({
        Email: [email, Validators.required],
        token: [token, Validators.required],
        Password: ['', [Validators.required],[Validators.pattern('((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')]],
        ConfirmPassword: ['', [Validators.required]]
      }, { validator: passwordMatchValidator } );
    });
  }
  onReset(){
    if(this.resetForm.value){
  
    this.auth.resetPassword(this.resetForm.value)
    .subscribe({
      next:(res=>{
       
        alert(res.message);
        
        this.resetForm.reset();
        this.router.navigate(['/login']);
      })
      ,error:(err=>{
        alert(err?.error.message)
      })
    })
      console.log(this.resetForm.value)
    }
    else{
      this.validateAllFormsFields(this.resetForm);
    }
  }
  private validateAllFormsFields(formGroup:FormGroup){
    Object.keys(formGroup.controls).forEach(field=>{
      const control=formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsDirty({onlySelf:true});
      }else if(control instanceof FormGroup){
        this.validateAllFormsFields(control)
      }
    })
    
  }
}
