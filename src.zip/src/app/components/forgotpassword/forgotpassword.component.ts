import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotForm!:FormGroup;  
constructor(private fb:FormBuilder,private auth:AuthService,private router: Router){}
ngOnInit(): void {
 
  this.forgotForm=this.fb.group(
    
     {
      Email:['',Validators.required],
     }
    
     
  )
}
  onForgot(){
    if(this.forgotForm.valid){
  
    this.auth.forgotPassword(this.forgotForm.value)
    .subscribe({
      next:(res=>{
        alert(res.message)
        this.forgotForm.reset();
        
      })
      ,error:(err=>{
        alert(err?.error.message)
      })
    })
      console.log(this.forgotForm.value)
    }
    else{
      this.validateAllFormsFields(this.forgotForm);
      alert("Form is invalid");
    }
  }
  private validateAllFormsFields(formGroup:FormGroup){
    Object.keys(formGroup.controls).forEach(field=>{
      const control=formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsDirty({onlySelf:true});
      }else if(control instanceof FormGroup){
        this.validateAllFormsFields(control)
      }
    })
    
  }
}
