import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit{
signUpForm!:FormGroup;
    constructor(private fb:FormBuilder,private auth:AuthService,private router: Router){}

 
  ngOnInit(): void {
    this.signUpForm=this.fb.group(
      {
        Name:['',Validators.required,Validators.pattern('[a-zA-Z ]*')],
        Password:['',Validators.required,Validators.pattern('((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')],
        Email:['',Validators.required,Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')],
        BusinessName:['',Validators.required,Validators.pattern('[a-zA-Z ]*')],
        PhoneNumber:['',Validators.required,Validators.pattern('^[0-9\-\+]{9,15}$')],
        ModeOfBusiness:['',Validators.required,Validators.pattern('[a-zA-Z ]*')],
        Category:['',Validators.required]
      }
    )
   
  }
 
  
  onSignUp(){
    console.log(this.signUpForm)
    if(this.signUpForm.value){
  
    this.auth.signUp(this.signUpForm.value)
    .subscribe({
      next:(res=>{
        alert(res.message);
        this.signUpForm.reset();
        this.router.navigate(['/login']);
        
      })
      ,error:(err=>{
        alert(err?.error.message)
      })
    })
      console.log(this.signUpForm.value);
     
      
    }
    else{
      this.validateAllFormsFields(this.signUpForm);
      alert("Form is invalid");
    }
  }
private validateAllFormsFields(formGroup:FormGroup){
  Object.keys(formGroup.controls).forEach(field=>{
    const control=formGroup.get(field);
    if(control instanceof FormControl){
      control.markAsDirty({onlySelf:true});
    }else if(control instanceof FormGroup){
      this.validateAllFormsFields(control)
    }
  })
  
}
onPhoneNumberInput(event: any): void {
  const inputValue = event.target.value;
  event.target.value = inputValue.replace(/[^0-9]/g, ''); 
  if (inputValue.length > 10) {
    event.target.value = inputValue.slice(0, 10);
  }
}
  }

   

