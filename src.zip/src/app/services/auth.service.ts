import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl:string="https://localhost:7089/api/User/"

  constructor(private http:HttpClient) { }

  signUp(userObj:any){
    return this.http.post<any>(`${this.baseUrl}register`,userObj);
  }

  login(logObj:any){
    return this.http.post<any>(`${this.baseUrl}login`,logObj);
  }
  
  forgotPassword(forgot:any){
    return this.http.post<any>(`${this.baseUrl}forgotpassword`,forgot);
  }

  resetPassword(reset:any){
    return this.http.post<any>(`${this.baseUrl}resetpassword`,reset);
  }
}
